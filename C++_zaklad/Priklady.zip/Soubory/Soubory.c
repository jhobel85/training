#define _CRT_SECURE_NO_WARNINGS

#include <assert.h>
#include <malloc.h>
#include <stdio.h>
#include <string.h>

long velikost(const char* nazev)
{
	long velikost = EOF;
	FILE* f = fopen(nazev, "rb");
	if (f != NULL)
	{
		if (0 == fseek(f, 0L, SEEK_END))
		{
			velikost = ftell(f);
		}
		fclose(f);
	}
	return velikost;
}

size_t kopirujSoubor(const char* kopie, const char* original)
{
	const int n = 64 * 1024;
	size_t pocetZapsanychBajtu = 0;
	void* buf = NULL;
	FILE* src = NULL;
	FILE* dst = NULL;

	buf = malloc(n);
	if (buf == NULL)
	{
		goto konec;
	}
	src = fopen(original, "rb");
	if (src == NULL)
	{
		goto konec;
	}
	dst = fopen(kopie, "wb");
	if (dst == NULL)
	{
		goto konec;
	}

	assert(buf != NULL && src != NULL && dst != NULL);
	size_t precteno;

	while (0 != (precteno = fread(buf, 1, n, src)))
	{
		pocetZapsanychBajtu += fwrite(buf, 1, precteno, dst);
	}

konec:
	if (dst != NULL)
	{
		fclose(dst);
		dst = NULL;
	}
	if (src != NULL)
	{
		fclose(src);
		src = NULL;
	}
	if (buf != NULL)
	{
		free(buf);
		buf = NULL;
	}
	return pocetZapsanychBajtu;
}

void ctiSoubor(const char* nazev)
{
	//v binarnim rezimu by se zapisovali data bez prekladu - tzn. new line 1 char.
	FILE* f = fopen(nazev, "rt"); // CR LF -> new line jsou 2 charactery na Windows (na Linuxu jen 1)
	if (f != NULL)
	{
		enum { n = 24 }; // symbol, ktery je compile time hodnota
		char line[n] = "";
		size_t znaky = 0;
		size_t radky = 1; //pocet newline characters + 1 prvni radka

		while (fgets(line, n, f)) // NULL nebo No-NULL -> pointer automaticky preveen na boolean
		{
			fputs(line, stdout); // nedava newline automaticky po poctu n
			znaky += strlen(line); // pocet znaku na radce
			if (strchr(line, '\n'))
			{
				++radky;
			}
		}
		fclose(f);

		printf("\n");
		printf("znaky = %zd\n", znaky);
		printf("radky = %zd\n", radky);		
	}
}

int main()
{
	printf("Soubory:\n");
	ctiSoubor(__FILE__);
	printf("velikost      = %ld byte\n", velikost(__FILE__));
	printf("kopirujSoubor = %zd byte\n", kopirujSoubor("KOPIE.BIN", __FILE__));
	return 0;
}
